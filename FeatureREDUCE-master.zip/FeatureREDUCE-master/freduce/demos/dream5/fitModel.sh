#!/bin/sh

java -Xmx4000M FeatureReduce dream5.init -i DREAM5_TF1.txt -ids TF_1 -displayMotifs No
