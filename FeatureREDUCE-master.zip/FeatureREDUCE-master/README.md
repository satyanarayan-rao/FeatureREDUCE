FeatureREDUCE v1.10
=

This software is described in:

Todd. R. Riley, Allan Lazarovici, Richard S. Mann, and Harmen J. Bussemaker  
Building accurate sequence-to-affinity models from high-throughput in vitro  
protein-DNA binding data using FeatureREDUCE  
*eLife*, in revision
